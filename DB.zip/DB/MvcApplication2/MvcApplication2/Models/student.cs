﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication2.Models
{
    public class student
    {
        public int studentId { get; set; }
        public int UserDemoId { get; set; }
        public virtual UserDemo Userdemo { get; set; }
        public String sname { get; set; }
        public String semail { get; set; }
        public Gender Genderlist { get; set; }

    }
    public enum Gender
    {
        Male,
        Female
    }
}